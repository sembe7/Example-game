﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class flowBlock : MonoBehaviour {
	
	GameTimeLVL3 lvl3;
	public Material[] mateFlow;
	public Renderer rendFlow;
	public GameObject block;
	Vector3 movePositions= new Vector3(-0.0f, -4.0f, 0.0f);
	Vector3 FirstPositions= new Vector3(-4.0f, -4.0f, 0.0f);
		public float speed = 1f;

	GameObject[] bls;
	GameObject[] bl;
	int blength=0;
	int blocks, blsLen = 15, blsIdx = 0;
	Vector3 startPos;
	void Start () {
		lvl3=GameObject.Find("Time").GetComponent<GameTimeLVL3>();
		bls = new GameObject[blsLen];
		startPos = transform.position;
		bls[blsIdx] = Instantiate(block,startPos,transform.rotation) as GameObject;
	}
	void Update () {
		int Rindex=Random.Range(0,mateFlow.Length);
		Material material=mateFlow[Rindex];
		var pos = transform.position;
    	 pos.x += 1;
		for (int i = 0; i <= blsIdx; i ++) {
			transform.position = pos;
			if ( blsIdx < blsLen - 1 && bls[i].transform.position.x >= -4.62f && bls[i].transform.position.x <= -4.60f) {
				print("AAAAAAAAAAAAAAa");
				blsIdx ++;
				bls[blsIdx] = Instantiate(block,new Vector3(-7.0f,-4.0f,0.0f),transform.rotation) as GameObject;
				bls[blsIdx-1].GetComponent<Renderer>().sharedMaterial=material;
				bls[blsIdx-1].name="block3"+Rindex;
			}
			bls[i].transform.position += Vector3.right * 1*Time.deltaTime*speed;
		}
	}

	
}
