﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class blocksLVL3 : MonoBehaviour {

	// Use this for initialization
	//public int BlockInd;
	public GameObject brick3;
	public Material[] mate;
    public Renderer rend;
	public int indexb;
	public Transform rowContainer;
	public float currentSpawnY;
	private Vector2 desiredPosition;
	public static int[,] ball1;
	public float speed = 2.0f;
     private int direction = 1;
	 private static int[] blockSave;
	 Vector3 movePosition = new Vector3(5.5f, -3.8f, 0f);
    GameObject br;
	void Start () {
		ball1=new int[6,3];
		blockSave=new int[3];
		//Change();
		
		for(int t=0;t<3;t++){
	//	br= Instantiate(brick3,transform.position,transform.rotation) as GameObject;
		
		//GenerateNewRow();
		}
	}
	void Change() {
		for(int i=0;i<6;i++){
			for(int j=0; j<2;j++){
				indexb = Random.Range(0, mate.Length);	
				ball1[i,j] = indexb;	
	
				//print(indexb);
				Material materials=mate[indexb];
				int x=0;
				br = Instantiate(brick3,new Vector2(x++,0), transform.rotation );
				br.GetComponent<Renderer>().sharedMaterial=materials;				
				br.name="block3"+indexb;
				int offset=j%2;
				br.transform.position=new Vector3(transform.position.x+i*1.5f, transform.position.y+1.5f*offset, transform.position.z);
				//for(int x=-1;x)
		// 		  if (transform.position.x > rightLimit) {
        //      direction = -1;
             
        //  }
        //  else if (transform.position.x < leftLimit) {
        //      direction = 1;
             
        //  }
				//br.transform.Translate(Vector3.right * direction * speed * Time.deltaTime);
				// Vector3 pos=transform.position;
				// if(transform.position.x<=-3.0f){
				// 	pos.x=pos.x+1.0f;
				// 	br.transform.position=new Vector3(pos.x, transform.position.y+1.5f, transform.position.z);
				// }
				
				//GetComponent<Ball>().BlockInd=indexb;		
				
			}
		}
	}
	// private void GenerateNewRow(){
	// 	GameObject go=Instantiate(brick3)as GameObject;
	// 	go.transform.SetParent(rowContainer);
	// 	go.transform.localPosition= Vector2.down*currentSpawnY;	
	// 	currentSpawnY-=0.37f;
	// 	desiredPosition=Vector2.down*(2.5f*currentSpawnY);

	// }
	// Update is called once per frame
	void Update () {
			// if(br.transform.position!=movePosition){
			// 	//WaitForSeconds(1);
			// 	Vector3 newPos=Vector3.MoveTowards(br.transform.position,movePosition,speed*Time.deltaTime);
			// 	br.transform.position=newPos;
			// 	//yield return new WaitForSeconds(5);
			// }
			
	}

}
