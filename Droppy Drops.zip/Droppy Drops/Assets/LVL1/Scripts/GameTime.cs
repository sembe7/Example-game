﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameTime : MonoBehaviour {
	public Text textTime;
	float StartTime;
	// Use this for initialization
	void Start () {
		StartTime=Time.time;
	}
	
	// Update is called once per frame
	void Update () {
		float ti=Time.time-StartTime;
		string min = ((int)ti/60).ToString();
		string sec = ((int)ti%60).ToString();
		textTime.text="time:"+min+":"+sec;
		if(min=="1"){
			print("dead=========================");
		}
	}
}
