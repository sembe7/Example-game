﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BrickScript : MonoBehaviour {

	// Use this for initialization
	GameManagerScript GMS;
	void Start () {
		GMS=GameObject.Find("GameManager").GetComponent<GameManagerScript>();
	}
	
	// Update is called once per frame
	void Update () {
		for(int i=0; i<7; i++){
			for(int column=0; column <3; column++){
				
			}
		}
	}
	void OnCollisionEnter(){
		Destroy(gameObject);
		GMS.Score +=10;
	}
}
