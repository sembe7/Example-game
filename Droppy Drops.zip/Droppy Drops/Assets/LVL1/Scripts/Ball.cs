﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Ball : MonoBehaviour {
	
	
	public int ballindex;
	public GameObject heart3,heart2,heart;
	void Start () {
		// heart3.gameObject.SetActive(true);
		// heart2.gameObject.SetActive(true);
		// heart.gameObject.SetActive(true);
	}
	void Update () {
		//block=GameObject.Find("block").GetComponent<blocks>();
		 //hhdhdh=block.indexb;
		 
	}
	void OnCollisionEnter(Collision col){
	//	col.gameObject.GetComponent<blocks>();

		if (("block" + ballindex) == col.gameObject.name) {
			Destroy(col.gameObject);
			Debug.Log("Time = " + System.TimeSpan.Zero);
			DeadZone.Score+=10;

		} else if (col.gameObject.name.StartsWith("block")){
			DeadZone.life--;
			print(DeadZone.life);
			if(DeadZone.life==2){
				heart3.gameObject.SetActive(false);
			}else if(DeadZone.life==1){
				heart2.gameObject.SetActive(false);
			}
			else if(DeadZone.life==0){
				heart.gameObject.SetActive(false);
			}
		}
		
		if (DeadZone.life <= 0) {
			print("GAME OVEREEEEEEEEEEEEER!!!!!!!!!!");

		}
		if(DeadZone.Score>=120){
			print("You Win");
		}
		Destroy(gameObject);
		//print(DeadZone.Score);
		//print(("block" + ballindex) + ", " + col.gameObject.name + ", " + DeadZone.life);
		
		
		
	
		
	}
}

