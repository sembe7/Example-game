﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class blocks : MonoBehaviour {

	// Use this for initialization
	//public int BlockInd;
	public GameObject brick;
	public Material[] mate;
    public Renderer rend;
	public int indexb;
	public static int[,] ball1;
	void Start () {
		ball1=new int[6,3];
		Change();
	}
	void Change() {
		for(int i=0;i<6;i++){
			for(int j=0; j<2;j++){
				indexb = Random.Range(0, mate.Length);	
				ball1[i,j] = indexb;	
	
				//print(indexb);
				Material materials=mate[indexb];
				GameObject br = Instantiate(brick,transform.position, transform.rotation );
				br.GetComponent<Renderer>().sharedMaterial=materials;				
				br.name="block"+indexb;
				int offset=j%2;
				//for(int x=-1;x)
				br.transform.position= new Vector3(transform.position.x+i*1.5f, transform.position.y+1.5f*offset, transform.position.z);
				//GetComponent<Ball>().BlockInd=indexb;		
			}
		}
	}
	// Update is called once per frame
	void Update () {
	}
}
