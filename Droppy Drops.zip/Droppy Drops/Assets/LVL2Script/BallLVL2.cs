﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallLVL2 : MonoBehaviour {
	
	
	public int ballindex2;
	public GameObject heart3,heart2,heart;
	void Start () {
		heart3.gameObject.SetActive(true);
		heart2.gameObject.SetActive(true);
		heart.gameObject.SetActive(true);
	}
	void Update () {
		//block=GameObject.Find("block").GetComponent<blocks>();
		 //hhdhdh=block.indexb;
		 
	}
	void OnCollisionEnter(Collision col){
	//	col.gameObject.GetComponent<blocks>();
			print(ballindex2);
		if (("block2" + ballindex2) == col.gameObject.name) {
			
			Destroy(col.gameObject);
			//Debug.Log("Time = " + System.TimeSpan.Zero);
			DeadZoneLVL2.Score+=10;

		} else if (col.gameObject.name.StartsWith("block2")){
			DeadZoneLVL2.life--;
			//print(DeadZoneLVL2.life);
			// if(DeadZoneLVL2.life==2){
			// 	heart3.gameObject.SetActive(false);
			// }else if(DeadZoneLVL2.life==1){
			// 	heart2.gameObject.SetActive(false);
			// }
			// else if(DeadZoneLVL2.life==0){
			// 	heart.gameObject.SetActive(false);
			// }
		}
		
		if (DeadZoneLVL2.life <= 0) {
			print("GAME OVEREEEEEEEEEEEEER!!!!!!!!!!");

		}
		if(DeadZoneLVL2.Score>=120){
			print("You Win");
		}
		Destroy(gameObject);
		//print(DeadZone.Score);
		print(("block" + ballindex2) + ", " + col.gameObject.name + ", " + DeadZone.life);
		
		
		
	
		
	}
}

