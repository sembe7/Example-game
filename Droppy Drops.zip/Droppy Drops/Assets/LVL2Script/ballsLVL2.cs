﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ballsLVL2 : MonoBehaviour {
	changesLVL2 change;
	public GameObject ball2;

	//public GameObject blocks;
	public int ind2;
	void Start(){
		change = GameObject.Find("Sample").GetComponent<changesLVL2>();
		}
	void Update () {
		
		//if((Input.GetMouseButtonDown(0))){
			Plane objPlane= new Plane(Camera.main.transform.forward, this.transform.position);
			Ray mRay= Camera.main.ScreenPointToRay(Input.mousePosition);
			float rayDist;
			Vector3 v = new Vector3(0, 0, 0);
			if(objPlane.Raycast(mRay, out rayDist))
				v = mRay.GetPoint(rayDist);
			if (v.x >= -4.5 && v.x <= 4.5 && v.y >= -1.5 && v.y <= 3.5) {
				this.transform.position = v;
				//ind2=ind1;
				ind2=change.index;
				Material material=change.mate[ind2];
				GameObject sdf = Instantiate(ball2,transform.position,transform.rotation);
				//sdf.GetComponent<Renderer>().sharedMaterial = ballSaved.GetComponent<Renderer>().sharedMaterial;	
			
			sdf.GetComponent<Renderer>().sharedMaterial=material;
			sdf.GetComponent<BallLVL2>().ballindex2 = ind2;
			
		
	}
	}
	
	
}

