﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class changesLVL2 : MonoBehaviour
{
    public Material[] mate;
    public Renderer rend;
    public GameObject ballq;
	public int index;

    
    void Update()
    {

        if (Input.GetMouseButtonDown(0))
        {
            GetRand();
        }
    }
    public int GetRand()
    {
        index = Random.Range(0, mate.Length);
        rend.sharedMaterial = mate[index];
        return index;
    }

}
