﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class blocksLVL2 : MonoBehaviour {

	// Use this for initialization
	//public int BlockInd;
	public GameObject brick2;
	public Material[] mate;
    public Renderer rend;
	public int indexb;
	public Transform rowContainer;
	public float currentSpawnY;
	private Vector2 desiredPosition;
	public static int[,] ball1;
	void Start () {
		ball1=new int[10,3];
		Change();
		//GenerateNewRow();
	}
	void Change() {
		//if(Input.GetMouseButton(0)){
		for(int i=0;i<10;i++){
			for(int j=0; j<1;j++){
				indexb = Random.Range(0, mate.Length);	
				ball1[i,j] = indexb;	
	
				//print(indexb);
				Material materials=mate[indexb];
				int x=0;
				GameObject br = Instantiate(brick2,new Vector2(x++,0), transform.rotation );
				br.GetComponent<Renderer>().sharedMaterial=materials;				
				br.name="block2"+indexb;
				int offset=j%2;
				//for(int x=-1;x)
				br.transform.position= new Vector3(transform.position.x+i*1f, transform.position.y+1f*offset, transform.position.z);
				//GetComponent<Ball>().BlockInd=indexb;	
			//}	
			}
		}
	}
	private void GenerateNewRow(){
		GameObject go=Instantiate(brick2)as GameObject;
		go.transform.SetParent(rowContainer);
		go.transform.localPosition= Vector2.down*currentSpawnY;	
		currentSpawnY-=0.37f;
		desiredPosition=Vector2.down*(2.5f*currentSpawnY);

	}
	// Update is called once per frame
	void Update () {
		
	}
}
