﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Danger2LVL2 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
		   public float rightLimit = 4.0f;
     public float leftLimit = -4.0f;
     public float speed = 2.0f;
     private int direction = 1;
	 void Update () {

        
         if (transform.position.x > rightLimit) {
             direction = -1;
             
         }
         else if (transform.position.x < leftLimit) {
             direction = 1;
             
         }
          transform.Translate(Vector3.right * direction * speed * Time.deltaTime);
      }
}
