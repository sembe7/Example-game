﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class GameManagerScript : MonoBehaviour {

	// Use this for initialization
	public int Lives=3;
	public int bricks;
	public int Score=0;
	public Text ScoreText;
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	public void UpdateGUI(){
		if(Lives<=0){
			Debug.Log("Game Over");
		}
		ScoreText.text=("Score:" + Score.ToString());
		if(bricks <= 0){
			Debug.Log("Win Game");
		}
	}
}
