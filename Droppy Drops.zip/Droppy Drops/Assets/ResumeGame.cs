﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResumeGame : MonoBehaviour {

	// Use this for initialization
	public GameObject pausePanel;
	void Awake(){
		pausePanel.SetActive(false);
	}
	public void PauseGame(){
		Time.timeScale=0f;
		pausePanel.SetActive(true);
	}

	public void Resume(){
		Time.timeScale=1f;
		pausePanel.SetActive(false);
	}

	public void quickGame(){
		Time.timeScale=1f;
		Application.LoadLevel("Start");
	}
}
